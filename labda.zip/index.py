def lambda_handler(event, context):
    # TODO implement
    print ("HelloWorld")
    return 'Hello from Lambda - I am changed'
